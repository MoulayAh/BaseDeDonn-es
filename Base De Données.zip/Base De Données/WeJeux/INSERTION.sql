-------------------------------------------------------------
-- INSERTIONS
--------------------------------------------------------------


-- Insertion des profils
INSERT INTO WeJeux.Profil (nomUtilisateur, nom, prenom, adresseMail, numTel, carteBancaire)
VALUES 
('dagnetti', 'AGNETTI', 'Dylan', 'dylan.agnetti@example.com', 0612345678, '4532015112830366'),
('youadah', 'OUADAH', 'Yanis', 'yanis.ouadah@example.com', 0612345679, '4716523487543201'),
('eerdogan', 'ERDOGAN', 'Enes', 'enes.erdogan@example.com', 0612345680, '6011826734520987'),
('kpatel', 'PATEL', 'Kishan', 'kishan.patel@example.com', 0612345681, '4024007101234567'),
('amimoun', 'MIMOUN', 'Anton', 'anton.mimoun@example.com', 0612345682, '5248491042639812'),
('mcataldi', 'CATALDI', 'Mario', 'mario.cataldi@example.com', 0612345683, '4532513567910345'),
('pbonnot', 'BONNOT', 'Philippe', 'philippe.bonnot@example.com', 0612345684, '4916015516234982'),
('jrety', 'RETY', 'Jean Hugue', 'jean.rety@example.com', 0612345685, '4485729823184023'),
('mhomps', 'HOMPS', 'Marc', 'marc.homps@example.com', 0612345686, '4716906548367291'),
('brahim', 'BRAHIM', 'Ilyes', 'ilyes.brahim@example.com', 0612345687, '4024007193847290'),
('hanoune', 'HANOUNE', 'Boude', 'boude.hanoune@example.com', 0612345688, '5112753498752103'),
('eljamali', 'ELJAMALI', 'Ahmed', 'ahmed.eljamali@example.com', 0612345689, '6011111109876543'),
('user1', 'USER', '1', 'user1@example.com', 0612345690, '4532873214753980'),
('user2', 'USER', '2', 'user2@example.com', 0612345691, '4916019846123098'),
('user3', 'USER', '3', 'user3@example.com', 0612345692, '4485032149823754'),
('user4', 'USER', '4', 'user4@example.com', 0612345693, '4024007102345891'),
('user5', 'USER', '5', 'user5@example.com', 0612345694, '5248491005623410'),
('user6', 'USER', '6', 'user6@example.com', 0612345695, '4532015112845920'),
('user7', 'USER', '7', 'user7@example.com', 0612345696, '4716523487295623'),
('user8', 'USER', '8', 'user8@example.com', 0612345697, '6011826734298054');


-- Insertion des jeux vidéo (5 solos et 5 multijoueurs)
INSERT INTO WeJeux.JeuxVideo (idJeux,titre, descriptif)
VALUES 
(1,'Call of Duty', 'Jeu de tir multijoueur'),
(2,'The Witcher 3', 'Jeu d`aventure solo'),
(3,'Minecraft', 'Jeu de construction multijoueur'),
(4,'Red Dead Redemption 2', 'Jeu d`action solo'),
(5,'FIFA 22', 'Jeu de football multijoueur'),
(6,'Skyrim', 'Jeu de rôle solo'),
(7,'League of Legends', 'Jeu de stratégie multijoueur'),
(8,'Cyberpunk 2077', 'Jeu de science-fiction solo'),
(9,'Fortnite', 'Jeu de bataille royale multijoueur'),
(10,'Elden Ring', 'Jeu d`action-aventure solo');

-- Insertion des données spécifiques pour JeuxSolo
INSERT INTO WeJeux.JeuxSolo (idJeux, tempsDeJeux)
VALUES 
(2, 120), 
(4, 100), 
(6, 150), 
(8, 200), 
(10, 180);


-- Insertion des données spécifiques pour JeuxMulti
INSERT INTO WeJeux.JeuxMulti (idJeux, nbExtension)
VALUES 
(1, 5), 
(3, 10), 
(5, 7), 
(7, 12), 
(9, 6);

-- Insertion des parties solo
-- Insertion des parties solo
INSERT INTO WeJeux.SauvegardeSolo (idSauvegarde, idJeux, nomUtilisateur, nbVie, points, niveauAtteint)
VALUES 
(1, 2, 'dagnetti', 3, 5000, 15), 
(2, 4, 'youadah', 2, 8000, 20), 
(3, 6, 'eerdogan', 5, 10000, 25), 
(4, 8, 'kpatel', 1, 12000, 30), 
(5, 10, 'amimoun', 4, 9000, 22), 
(6, 2, 'mcataldi', 3, 7000, 18), 
(7, 4, 'pbonnot', 2, 7500, 19), 
(8, 6, 'jrety', 3, 6000, 16), 
(9, 8, 'mhomps', 4, 6500, 17), 
(10, 10, 'dagnetti', 5, 14000, 35);


-- Insertion des serveurs
INSERT INTO WeJeux.Serveur (IP, nom, capaciteMax, idJeux)
VALUES 
('192.168.1.1', 'Serveur Alpha', 100, 1),
('192.168.1.2', 'Serveur Beta', 200, 3),
('192.168.1.3', 'Serveur Gamma', 150, 5),
('192.168.1.4', 'Serveur Delta', 50, 7),
('192.168.1.5', 'Serveur Epsilon', 300, 9);

-- Insertion des parties multijoueurs
INSERT INTO WeJeux.SauvegardeMulti (numPartie, idJeux, nomUtilisateur, IP, JoueurDepart, JoueurAdverse, JoueurGagnant)
VALUES 
(1, 1, 'dagnetti', '192.168.1.1', 'dagnetti', 'youadah', 'youadah'),
(2, 3, 'youadah', '192.168.1.2', 'youadah', 'eerdogan', 'eerdogan'),
(3, 5, 'eerdogan', '192.168.1.3', 'eerdogan', 'kpatel', 'kpatel'),
(4, 7, 'kpatel', '192.168.1.4', 'kpatel', 'amimoun', 'amimoun'),
(5, 9, 'amimoun', '192.168.1.5', 'amimoun', 'mcataldi', 'mcataldi'),
(6, 1, 'mcataldi', '192.168.1.1', 'mcataldi', 'pbonnot', 'pbonnot'),
(7, 3, 'pbonnot', '192.168.1.2', 'pbonnot', 'jrety', 'jrety'),
(8, 5, 'jrety', '192.168.1.3', 'jrety', 'mhomps', 'mhomps'),
(9, 7, 'mhomps', '192.168.1.4', 'mhomps', 'dagnetti', 'dagnetti'),
(10, 9, 'dagnetti', '192.168.1.5', 'dagnetti', 'youadah', 'youadah');



