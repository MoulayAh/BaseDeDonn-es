DROP SCHEMA IF EXISTS WeJeux CASCADE;
CREATE SCHEMA WeJeux;

------------------------------------------------------------
-- Table: Profil
------------------------------------------------------------
CREATE TABLE WeJeux.Profil(
    nomUtilisateur   VARCHAR (50) NOT NULL ,
    nom              VARCHAR (50) NOT NULL ,
    prenom           VARCHAR (50) NOT NULL ,
    adresseMail      VARCHAR (50) NOT NULL,
    numTel           INT  NOT NULL ,
    carteBancaire    VARCHAR  NOT NULL  ,
    CONSTRAINT Profil_PK PRIMARY KEY (nomUtilisateur)
);

------------------------------------------------------------
-- Table: JeuxVideo
------------------------------------------------------------
CREATE TABLE WeJeux.JeuxVideo(
    idJeux       SERIAL PRIMARY KEY, 
    titre        VARCHAR (50),
    descriptif   VARCHAR (50)
);

------------------------------------------------------------
-- Table: JeuxMulti
------------------------------------------------------------
CREATE TABLE WeJeux.JeuxMulti(
    idJeux INT PRIMARY KEY,   
    nbExtension INT NOT NULL 
) INHERITS (WeJeux.JeuxVideo);   

------------------------------------------------------------
-- Table: JeuxSolo
------------------------------------------------------------
CREATE TABLE WeJeux.JeuxSolo(
    idJeux INT PRIMARY KEY,  
    tempsDeJeux INT NOT NULL 
) INHERITS (WeJeux.JeuxVideo); 

------------------------------------------------------------
-- Table: Serveur
------------------------------------------------------------
CREATE TABLE WeJeux.Serveur(
    IP            VARCHAR (50) NOT NULL ,
    nom           VARCHAR (50) NOT NULL ,
    capaciteMax   INT  NOT NULL ,
    idJeux        INT ,
    CONSTRAINT Serveur_PK PRIMARY KEY (IP),
    CONSTRAINT Serveur_JeuxMulti_FK FOREIGN KEY (idJeux) REFERENCES WeJeux.JeuxMulti(idJeux) 
);

------------------------------------------------------------
-- Table: SauvegardeSolo
------------------------------------------------------------
CREATE TABLE WeJeux.SauvegardeSolo(
    idSauvegarde     SERIAL PRIMARY KEY,
    idJeux           INT  NOT NULL ,
    nomUtilisateur   VARCHAR (50) NOT NULL ,
    nbVie            INT  NOT NULL ,
    points           INT  NOT NULL ,
    niveauAtteint    INT  NOT NULL  ,
    CONSTRAINT SauvegardeSolo_idJeux_FK FOREIGN KEY (idJeux) REFERENCES WeJeux.JeuxSolo(idJeux),
    CONSTRAINT SauvegardeSolo_nomUtilisateur_FK FOREIGN KEY (nomUtilisateur) REFERENCES WeJeux.Profil(nomUtilisateur)
);

------------------------------------------------------------
-- Table: SauvegardeMulti
------------------------------------------------------------
CREATE TABLE WeJeux.SauvegardeMulti(
    numPartie        INT  NOT NULL ,
    idJeux           INT  NOT NULL ,
    nomUtilisateur   VARCHAR (50) NOT NULL ,
    IP               VARCHAR (50) NOT NULL ,
    JoueurDepart     VARCHAR (50) NOT NULL ,
    JoueurAdverse    VARCHAR (50) NOT NULL ,
    JoueurGagnant    VARCHAR (50) NOT NULL  ,
    CONSTRAINT SauvegardeMulti_PK PRIMARY KEY (numPartie),
    CONSTRAINT SauvegardeMulti_JeuxMulti_FK FOREIGN KEY (idJeux) REFERENCES WeJeux.JeuxMulti(idJeux),
    CONSTRAINT SauvegardeMulti_Ip_FK FOREIGN KEY (IP) REFERENCES WeJeux.Serveur(IP),
    CONSTRAINT SauvegardeMulti_nomUtilisateur_FK FOREIGN KEY (nomUtilisateur) REFERENCES WeJeux.Profil(nomUtilisateur),
    CONSTRAINT SauvegardeMulti_JoueurDepart_FK FOREIGN KEY (JoueurDepart) REFERENCES WeJeux.Profil(nomUtilisateur),
    CONSTRAINT SauvegardeMulti_JoueurAdverse_FK FOREIGN KEY (JoueurAdverse) REFERENCES WeJeux.Profil(nomUtilisateur),
    CONSTRAINT SauvegardeMulti_JoueurGagnant_FK FOREIGN KEY (JoueurGagnant) REFERENCES WeJeux.Profil(nomUtilisateur)
);
